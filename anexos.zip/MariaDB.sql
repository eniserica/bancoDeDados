-- DDL - Gerenciamento de tabelas
-- NÃO esquecer do ; no final 
#Criando tabelas 
CREATE TABLE pessoas (nome VARCHAR(100), cpf CHAR(11), descricao MEDIUMTEXT);
CREATE TABLE teste (nome VARCHAR(100), cpf CHAR(11), descricao MEDIUMTEXT);
#Deletar uma tabela 
DROP TABLE teste;

-- TIPOS DE DADOS PARA AS COLUNAS 
## TEXTO - APENAS O CHAR E VARCHAR aceita caracteres especiais - ' # $ % ¨ @ 
# CHAR(X) -> aceita todos os textos com 0 a 255 caracteres 
# VARCHAR(X) -> aceita todos os textos com 0 a 65535 caracteres 
# TINYTEXT -> apenas texto com até 255 caracteres
# MEDIUMTEXT -> apenas texto com até 16777215 caracteres

## NUMÉRICO - 
# BIT(X) -> aceita de 1 a 64 caracteres 
# TINYINT(X) -> aceita de 1 a 255 caracteres 
# BOOL -> 0 é falso e qualquer outro valor é verdadeiro 
# INT(X) -> aceita valores entre -2147483648 a 2147483648
# DECIMAl(x,y) -> x - Quantidade de digitos - y - decimal apos a virgula 
# DECIMAl (10,2)

##DATA 
# DATE -> Aceita uma data no formato YYYY-MM-DD (ano,mes e dia)
# DATATIME -> Aceita data com horario no formato YYYY-MM-DD hh:mm:sspessoas
# TIMESTAMP-> Aceita data com horario no formato DATETIME, porém entre os anos 1970 a 2038

CREATE TABLE produtos (nome VARCHAR(255), sku CHAR(5), informacoes MEDIUMTEXT);
SHOW TABLES;
#Inserir dados nessa tabela 
INSERT INTO produtos (nome, sku, informacoes) VALUES ('Playstation 5', 'PS5XY', 'Última geração');
INSERT INTO produtos (nome, sku, informacoes) VALUES ('XBOX S', 'SERIE', 'Última geração 2');
INSERT INTO produtos (nome, sku, informacoes) VALUES ('XBOX X', 'SERIE', 'Última geração 3');
#Mostrar/Selecionar os dados de uma tabela 
-- * seleciona todos da tabela
SELECT * FROM produtos; 

##ATT01 - Crie uma tabela servidores com as colunas de nome, espaco_disco, ligado 
CREATE TABLE servidores (nome VARCHAR(255), espaco_disco INT(10), ligado BOOL);
SHOW TABLES;
INSERT INTO servidores (nome, espaco_disco, ligado) VALUES ("Servidor 06", 50, 1);
SELECT * FROM servidores; 

#ATT02 - Crie uma tabela aniversario com as colunas de nome, data de nascimento 
CREATE TABLE aniversario (nome VARCHAR(255), data_nascimento DATE);
INSERT INTo aniversario (nome, data_nascimento) VALUES("Érica Silveira", "2007-09-04");
INSERT INTo aniversario (nome, data_nascimento) VALUES("Beatriz Limeira", "2007-09-10");
INSERT INTo aniversario (nome, data_nascimento) VALUES("Maria Clara", "2007-12-29");
SELECT * FROM aniversario ; 

############# ALTERAR/MODIFICAR TABELAS ##############
CREATE TABLE usuarios (
  id INT,
  nome VARCHAR(100), 
  email VARCHAR(100),
  PRIMARY key (id)
);
INSERT into clientes(id, nome, email) VALUES    
(1,"João Silva", "joao@silva.com"),
(2,"Maria Souza", "maria@souza.com"); 
SELECT * FROM clientes ; 
DROP TABLE clientes;

-- Renomear uma tabela 
ALTER TABLE usuarios RENAME to clientes; 

-- Adicionar uma coluna 
ALTER TABLE clientes ADD COLUMN dt_nascimento DATE AFTER email;
ALTER TABLE clientes ADD COLUMN idade CHAR(5) AFTER dt_nascimento;
ALTER TABLE clientes ADD COLUMN id CHAR(5) AFTER dt_nascimento;


-- Remover uma coluna 
ALTER TABLE clientes DROP COLUMN dt_nascimento ; 

-- Modificar coluna existente (Tipo ou propriedade) 
ALTER TABLE clientes MODIFY COLUMN idade INT(10); 

-- Adiciona uma chave primaria 
ALTER table clientes add PRIMARY key (id);



                       



