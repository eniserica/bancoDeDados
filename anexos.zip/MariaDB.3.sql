##### ATT 01 #####
-- Fácil - Sistema de Biblioteca 

drop table usuarios;
drop TABLE livros;

CREATE table livros (
  titulo VARCHAR(255),
  autor VARCHAR(255),
  editora VARCHAR(255),
  ano_publicacao DATE, 
  ISBN VARCHAR(255),
  id INT PRIMARY KEY NOT NULL AUTO_INCREMENT
  );
  
CREATE table usuarios(
  id INT PRIMARY KEy NOT NULL AUTO_INCREMENT, 
  nome VARCHAR(255), 
  email VARCHAR(255),
  telefone VARCHAR(255)
  );
  
 CREATE table emprestimos(
   id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
   usuario_id INT NOT NULL, 
   livro_id INT NOT NULL, 
   data_emprestimo DATE, 
   data_devolucao DATE 
   
   FOREIGN KEY (livro_id) REFERENCES livros(id),
   FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
  );
  
  SELECT * from livros; 
  SELECT * from usuarios; 
  INSERT into livros (titulo, autor, editora, ano_publicacao, ISBN) VALUES ("A Metamorfose", "Franz Kafka", "Principis", "2019-09-27", "8594318782");
  INSERT INto usuarios (nome, email, telefone) VALUES ("Érica", "erica@email.com", "82 9-9363-4021");