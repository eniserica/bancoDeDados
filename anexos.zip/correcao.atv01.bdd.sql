#####Correção da Atividade 01 funcionarios ############

CREATE TABLE funcionarios (
  id INT PRIMARY KEY,
  nome VARCHAR(100),
  cargo VARCHAR(50),
  salario DECIMAL(10,2)
  );
  
#1 - adicionar uma nova coluna 
Alter table funcionarios add COLUMN data_admissao DATE AFTER nome; 
#2 - modificar uma coluna existente 
ALter table funcionarios MODIFY COLUMN salario DECIMAL(12,2);
#3 - renomear uma coluna 
ALTER table funcionarios RENAME COLUMN cargo to funcao ; 
#4 - remover uma coluna 
alter table funcionarios drop COLUMN data_admissao ;

#6 - adicionar uma coluna com restiração NOT NULL 
ALTER TABLE funcionarios ADD COLUMN email VARCHAR(255) NOT NULL; 
INSERT into funcionarios (id, nome, salario, email) VALUES (2, 'teste', 1000, "teste@teste.com");
SELECT * from funcionarios; 

#7 - alterar uma coluna para aceitar valores nulos 
Alter TABLE funcionarios MODIFY COLUMN email VARCHAR(100) NULL; 
INSERT into funcionarios (id, nome, salario, email) VALUES (4, 'teste', 1000);

#8 - adicionar uma coluna com valor padrão 
alter table funcionarios add COLUMN ativo BOOL DEFAULT TRUE;

#9 - renomear a tabela 
ALTER TABLE funcionarios RENAME to colaboradores; 

#10 - Criar um índice em uma tabela 
alter table colaboradores add INDEX idx_nome (nome); 

### Desafio Final 

CREATE TABLE produtos (
    codigo INT PRIMARY KEY,
    descricao VARCHAR(200),
    preco DECIMAL(10, 2)
);

alter TABLE produtos add COLUMN estoque INT;
ALter table produtos MODIFY COLUMN descricao MEDIUMTEXT;
alter TABLE produtos drop COLUMN preco;
alter TABLE produtos RENAME to itens_estoque;
