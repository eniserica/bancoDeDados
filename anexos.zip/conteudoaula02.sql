################ CONSTRAINTS / Restrições ################
#NOT NULL -> Não permite campos nulos 
CREATE table pessoas(
  nome VARCHAR(255) NOT NULL,
  idade INT 
); 
  
SELECT * from pessoas;
INSERT into pessoas (nome, idade) VALUES("Érica", 17);
INSERT into pessoas (nome, idade) VALUES ("", 17); -- String vazia não é considerada nulo 
INSERT into pessoas (nome, idade) VALUES ( null, 17); -- Erro 
INSERT into pessoas (nome) VALUES ("Silveira"); -- Aceita o insert 

#UNIQUE -> Campos únicos 
alter table pessoas add COLUMN email VARCHAR(100) UNIQUE; 
INSERT into pessoas (nome, idade, email) VALUES ("Érica Silveira", 17, "erica@email.com");
INSERT into pessoas (nome, idade, email) VALUES ("Érica", 17, "erica@email.com"); -- error campo de email já existe

# PRIMARY KEY -> é um identificador únicopessoas
CREATE TABLE produtos(
  id INT NOT NULL,
  nome VARCHAR(255),
  sku VARCHAR(10),
  PRIMARY KEy (id)
 );
 
 SELECT * from produtos;
 INSERT into produtos(id, nome, sku) VALUEs (1, "TV", "teste");
 INSERT into produtos(id, nome, sku) VALUEs (null, "TV", "teste"); -- Error 
 INSERT into produtos(id, nome, sku) VALUEs (1, "TV", "teste"); -- Error 
 INSERT into produtos(id, nome, sku) VALUEs (2, "TV2", "teste");
 
 # AUTO_INCREMENT -- coloca automaticamente a chave primaria (id) 
 CREATE table frutas(
   id INT PRIMARY KEY AUTO_INCREMENT NOT NULL, 
   nome VARCHAR(50)
   );
   
INSERT into frutas(nome) VALUES ("Uva"); 
INSERT into frutas(nome) VALUES ("Abacaxi"), ("Melão"); 
SELECT * from frutas;

#DEFAULT -> DEfine um valor padrão para a coluna 
CREATE table usuarios(
	id INT PRIMARY KEy AUTO_INCREMENT NOT NULL, 
  	statuss ENUM('ativo', 'inativo') DEFAULT 'ativo'
);

SELECT * from usuarios; 
alter TABLE usuarios ADD COLUMN nome VARCHAR(255) AFTER id; 
INSERT into usuarios (nome) VAlues ("pessoa1");
INSERT into usuarios (nome, statuss) VAlues ("pessoa2", 'ativo');
INSERT into usuarios (nome, statuss) VAlues ("pessoa3", 'inativo');
INSERT into usuarios (nome, statuss) VAlues ("pessoa4", 'pendente'); -- Error 

# EXERCICIO 
-- Crie uma tabela contas 
-- Insira as colunas id, nome, sobrenome, saldo, situacao (devendo) , data_nascimento
-- A coluna id deve ser chave primaria auto incremente e not null 
-- Encontre os melhores tipos para cada coluna
-- Adicione 3 registros

create table contas(
	id INT PRIMARY KEy AUTO_INCREMENT NOT NULL, 
  	nome VARCHAR(255),
  	sobrenome VARCHAR(255),
  	situacao ENUM('devendo', 'pagando') DEFAULT 'pagando',
  	saldo INT, 
  	data_nascimento DATE
);

SELECT * from contas;
INSERT into contas (nome, sobrenome, situacao, saldo, data_nascimento) VALUEs ("Érica", "Silveira", 'pagando', 2000.00, "2007-09-04");
INSERT into contas (nome, sobrenome, situacao, saldo, data_nascimento) VALUEs ("Beatriz", "Santos", 'pagando', 1500.00, "2007-09-10");
INSERT into contas (nome, sobrenome, situacao, saldo, data_nascimento) VALUEs ("Maria Clara", "Lira", 'pagando', 1500.00, "2007-12-29");

DROP table pessoas;
create table pessoa(
  id INT PRIMARY KEY AUTO_INCREMENT NOT NULL,
  nome VARCHAR(255) NOT NULL,
  idade INT
  );
  
 CREATE table endereco (
    id INT PRIMARY KEY AUTO_INCREMENT NOT NULL, 
    rua VARCHAR(255) NOT NULL, 
    numero VARCHAR(10),
    pessoa_id INT NOT NULL, 
    -- Relações das tabelas 
    
    FOREIGN KEY (pessoa_id) REFERENCES pessoa(id) 
    
 );
  
 SELECT * from pessoa ;
 SELECT * from endereco ;
   
 INSERT into pessoa (nome, idade) VALUES ("Érica", 17);
 INSERT into endereco (rua, numero, pessoa_id) VALUES ("Rua1", "322", 10); -- erro pessoa não existe 
 INSERT into endereco (rua, numero, pessoa_id) VALUES ("Rua1", "322", 1); -- ok
 
 drop TABLE pessoa;
 